#p6.py  Interface grafica para a Calculadora de IMC, Parte1
from tkinter import *
Master = Tk()

#Imagens
TitleImg = PhotoImage(file="TitleImg.png")
TableImg = PhotoImage(file="TableImg.png")
BottomImg = PhotoImage(file="BottomImg.png")
Box1Img = PhotoImage(file="Box1Img.png")
Box2Img = PhotoImage(file="Box2Img.png")

#Frames-Containers: Agrupadores de objetos na tela
Topframe = Frame(Master, relief='solid', bd=0, bg="#1c1c1a")  #gray
Topframe.place(width=991, height=407, x=0, y=0)
LabelTitle = Label(Topframe, image=TitleImg, borderwidth=0, compound="center", highlightthickness=0)
LabelTitle.place(x=0, y=0)
LabelTable = Label(Topframe, image=TableImg, borderwidth=0,compound="center", highlightthickness=0)
LabelTable.place(x=0, y=48)
BottomFrame = Frame(Master, relief='solid', bd=0,   bg="#1c1c3a")
BottomFrame.place(width=991, height=232, x=0, y=407)
LabelBottomImg = Label(BottomFrame, image=BottomImg, borderwidth=0,compound="center", highlightthickness=0)

LabelBottomImg.place(x=0, y=0)

Box1Frame = Frame(Master, relief='solid', bd=0,   bg="#B97A57")
Box1Frame.place(width=276, height=200, x=23, y=422)
LabelBox1Img = Label(Box1Frame, image=Box1Img, borderwidth=0, compound="center", highlightthickness=0)
LabelBox1Img.place(x=0, y=0)

Box2Frame = Frame(Master, relief='solid', bd=0,   bg="#7F7F7F")
Box2Frame.place(width=611, height=200, x=318, y=422)
LabelBox2Img = Label(Box2Frame, image=Box2Img, borderwidth=0, compound="center", highlightthickness=0)
LabelBox2Img.place(x=0, y=0)

#Configurações da tela Master
Master.geometry("951x634+-1152+200")  #951x634+50+50
Master.title("Calculadora de Indice de Massa Corporal-IMC")
Master.iconbitmap(default='ulab.ico')
mainloop()