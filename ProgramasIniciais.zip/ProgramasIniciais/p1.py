from tkinter import *
tela1 = Tk()
tela1.title("uLab Eletrônica")
#------------------



#-------------------
tela1.mainloop()

