#-----------------------------------------------------------------------------------------------------------------------
# Prog: p3
# Finalidade: Estudando o Label e o PhotoImage
# Data: 18/06/2020
# Dev: N.M.
# Outras informações:
# V43-uLab Eletrônica: https://www.youtube.com/watch?v=jfAUq0qYzQk
#-----------------------------------------------------------------------------------------------------------------------
from tkinter import *
tela1 = Tk()
#-----------------------------------------------------------------------------------------------------------------------
# Declarações Globais: Variaveis e constates
#-----------------------------------------------------------------------------------------------------------------------
var1=StringVar()
#-----------------------------------------------------------------------------------------------------------------------
# Funções
#-----------------------------------------------------------------------------------------------------------------------
def fbt1():
    print("Botão1")
    var1.set("Texto final!")

def mouseBtnEsquerdo(evento):
    tela1.title("uLab " + "x:" + str(evento.x) + " y:" + str(evento.y))
    print(tela1.geometry())

#-----------------------------------------------------------------------------------------------------------------------
# Widgets
#-----------------------------------------------------------------------------------------------------------------------
image1 = PhotoImage(file="img1.png")

fig1 = Label(tela1, image=image1)
label1 = Label(tela1, text="Label1", font="Arial 20 bold")
button1 = Button(tela1, text="Botão1")
input1 = Entry(tela1)
#---------------------------------------------------
# Layout Managers / Geometry Manager
# Pack
#fig1.pack(pady=10)
#label1.pack(pady=10)
#button1.pack(pady=10)
#input1.pack(pady=10)
# Grid Layout
fig1.grid(row=0, column=0, pady=10)
label1.grid(row=1, column=0, pady=10)
button1.grid(row=2, column=0, pady=10)
input1.grid(row=3, column=0, padx=20, pady=10)
# PLACE
#fig1.place(width=69, height=71, x=60, y=11)
#label1.place(width=86, height=30, x=52, y=97)
#button1.place(width=50, height=30, x=68, y=144)
#input1.place(width=111, height=18, x=37, y=197)
#tela1.geometry("182x247+-1015+324")
#----------------------------------------------------








#-----------------------------------------------------------------------------------------------------------------------
tela1.title("uLab Eletrônica")
tela1.iconbitmap(default="tela1.ico")
#tela1.geometry("488x411+-1015+324")
#tela1.wm_resizable(width=FALSE, height=FALSE)
tela1.bind('<Button-1>', mouseBtnEsquerdo)
tela1.mainloop()
#-----------------------------------------------------------------------------------------------------------------------
# E.O.F
#-----------------------------------------------------------------------------------------------------------------------



