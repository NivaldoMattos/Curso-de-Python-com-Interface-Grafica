#------------------
from tkinter import *
tela1 = Tk()
tela1.title("uLab Eletrônica")
tela1.iconbitmap(default="tela1.ico")
tela1.geometry("253x382+-857+497")
tela1.wm_resizable(width=FALSE, height=FALSE)
#------------------
def mouseBtnEsquerdo(evento):
    tela1.title("uLab " + "x:" + str(evento.x) + " y:" + str(evento.y))
    print(tela1.geometry())




#-------------------
tela1.bind('<Button-1>', mouseBtnEsquerdo)
tela1.mainloop()

